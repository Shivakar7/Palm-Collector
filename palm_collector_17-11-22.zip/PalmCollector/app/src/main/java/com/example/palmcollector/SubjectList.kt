package com.example.palmcollector

data class SubjectList(
    var subjects: MutableList<Subject>
): java.io.Serializable