package com.example.palmcollector;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import androidx.appcompat.widget.AppCompatImageView;
import com.google.mediapipe.formats.proto.LandmarkProto;
import com.google.mediapipe.formats.proto.LandmarkProto.NormalizedLandmark;
import com.google.mediapipe.solutions.hands.HandLandmark;
import com.google.mediapipe.solutions.hands.Hands;
import com.google.mediapipe.solutions.hands.HandsResult;
import java.util.List;

/** An ImageView implementation for displaying {@link HandsResult}. */
public class HandsResultImageView extends AppCompatImageView {
    private static final String TAG = "HandsResultImageView";

    private static final int LEFT_HAND_CONNECTION_COLOR = Color.parseColor("#30FF30");
    private static final int RIGHT_HAND_CONNECTION_COLOR = Color.parseColor("#FF3030");
    private static final int CONNECTION_THICKNESS = 8; // Pixels
    private static final int LEFT_HAND_HOLLOW_CIRCLE_COLOR = Color.parseColor("#30FF30");
    private static final int RIGHT_HAND_HOLLOW_CIRCLE_COLOR = Color.parseColor("#FF3030");
    private static final int HOLLOW_CIRCLE_WIDTH = 5; // Pixels
    private static final int LEFT_HAND_LANDMARK_COLOR = Color.parseColor("#FF3030");
    private static final int RIGHT_HAND_LANDMARK_COLOR = Color.parseColor("#30FF30");
    private static final int LANDMARK_RADIUS = 10; // Pixels
    private Bitmap latest;

    public HandsResultImageView(Context context) {
        super(context);
        setScaleType(AppCompatImageView.ScaleType.FIT_CENTER);
    }

    /**
     * Sets a {@link HandsResult} to render.
     *
     * @param result a {@link HandsResult} object that contains the solution outputs and the input
     *     {@link Bitmap}.
     */

    public void setHandsResult(HandsResult result) {
        if (result == null) {
            return;
        }
        Bitmap bmInput = result.inputBitmap();
        int width = bmInput.getWidth();
        int height = bmInput.getHeight();
        latest = Bitmap.createBitmap(width, height, bmInput.getConfig());
        Canvas canvas = new Canvas(latest);

        canvas.drawBitmap(bmInput, new Matrix(), null);
        int numHands = result.multiHandLandmarks().size();
        for (int i = 0; i < numHands; ++i) {
            drawLandmarksOnCanvas(
                    result.multiHandLandmarks().get(i).getLandmarkList(),
                    result.multiHandedness().get(i).getLabel().equals("Left"),
                    canvas,
                    width,
                    height);
        }
    }

    public boolean frontOrBack(HandsResult result) {
        int numHands = result.multiHandLandmarks().size();
        boolean isPalm = false;
        for (int i = 0; i < numHands; ++i) {
            if(result.multiHandedness().get(i).getLabel().equals("Left")){
                if(result.multiHandLandmarks().get(i).getLandmark(4).getX() > result.multiHandLandmarks().get(i).getLandmark(20).getX()){
                    isPalm = true;
                } else {
                    isPalm = false;
                }
            } else {
                if(result.multiHandLandmarks().get(i).getLandmark(4).getX() < result.multiHandLandmarks().get(i).getLandmark(20).getX()){
                    isPalm = true;
                } else {
                    isPalm = false;
                }
            }
        }
        return isPalm;
    }

    /** Updates the image view with the latest {@link HandsResult}. */
    public void update() {
        postInvalidate();
        if (latest != null) {
            setImageBitmap(latest);
        }
    }

    public boolean calculatehandedness(HandsResult result){
        int numHands = result.multiHandLandmarks().size();
        boolean isLeftHand = false;
        for (int i = 0; i < numHands; ++i) {
            isLeftHand = result.multiHandedness().get(i).getLabel().equals("Left");
        }
        return isLeftHand;
    }

    //result.multiHandLandmarks().get(0).getLandmarkList().get(HandLandmark.WRIST)

    public boolean palmPresent(HandsResult result) {
        boolean palm = false;
        if(result.multiHandLandmarks().get(0).getLandmarkList().get(HandLandmark.WRIST).hasPresence() &&
           result.multiHandLandmarks().get(0).getLandmarkList().get(HandLandmark.THUMB_CMC).hasPresence() &&
           result.multiHandLandmarks().get(0).getLandmarkList().get(HandLandmark.INDEX_FINGER_MCP).hasPresence() &&
           result.multiHandLandmarks().get(0).getLandmarkList().get(HandLandmark.MIDDLE_FINGER_MCP).hasPresence() &&
           result.multiHandLandmarks().get(0).getLandmarkList().get(HandLandmark.RING_FINGER_MCP).hasPresence())
        {
            palm = true;
        }
        return palm;
    }

    private void drawLandmarksOnCanvas(
            List<NormalizedLandmark> handLandmarkList,
            boolean isLeftHand,
            Canvas canvas,
            int width,
            int height) {
        // Draw connections.
        for (Hands.Connection c : Hands.HAND_CONNECTIONS) {
            Paint connectionPaint = new Paint();
            connectionPaint.setColor(
                    isLeftHand ? LEFT_HAND_CONNECTION_COLOR : RIGHT_HAND_CONNECTION_COLOR);
            connectionPaint.setStrokeWidth(CONNECTION_THICKNESS);
            NormalizedLandmark start = handLandmarkList.get(c.start());
            NormalizedLandmark end = handLandmarkList.get(c.end());
            canvas.drawLine(
                    start.getX() * width,
                    start.getY() * height,
                    end.getX() * width,
                    end.getY() * height,
                    connectionPaint);
        }
        Paint landmarkPaint = new Paint();
        landmarkPaint.setColor(isLeftHand ? LEFT_HAND_LANDMARK_COLOR : RIGHT_HAND_LANDMARK_COLOR);
        // Draws landmarks.
        for (LandmarkProto.NormalizedLandmark landmark : handLandmarkList) {
            canvas.drawCircle(
                    landmark.getX() * width, landmark.getY() * height, LANDMARK_RADIUS, landmarkPaint);
        }
        // Draws hollow circles around landmarks.
        landmarkPaint.setColor(
                isLeftHand ? LEFT_HAND_HOLLOW_CIRCLE_COLOR : RIGHT_HAND_HOLLOW_CIRCLE_COLOR);
        landmarkPaint.setStrokeWidth(HOLLOW_CIRCLE_WIDTH);
        landmarkPaint.setStyle(Paint.Style.STROKE);
        for (LandmarkProto.NormalizedLandmark landmark : handLandmarkList) {
            canvas.drawCircle(
                    landmark.getX() * width,
                    landmark.getY() * height,
                    LANDMARK_RADIUS + HOLLOW_CIRCLE_WIDTH,
                    landmarkPaint);
        }
    }
}