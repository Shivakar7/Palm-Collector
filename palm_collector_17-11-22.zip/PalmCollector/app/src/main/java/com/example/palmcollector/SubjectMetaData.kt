package com.example.palmcollector

import android.graphics.Bitmap
import java.io.File
import java.net.URI

data class SubjectMetaData (
    var Image : File
    //var Image : Bitmap
) : java.io.Serializable

